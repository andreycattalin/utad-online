function dameDogs() {
  var requestOptions = {
    method: "GET",
    redirect: "follow",
  };

  fetch("https://dog.ceo/api/breeds/image/random", requestOptions)
    .then((response) => response.json())
    .then((result) => {
      document.getElementById("myimage").src = result.message;
      document.getElementById("myimage").classList.add("rounded-5");
    })
    .catch((error) => console.log("error", error));
}

// dameDogs();

function damePelis() {
  var requestOptions = {
    method: "GET",
    redirect: "follow",
  };

  fetch("https://api.themoviedb.org/3/discover/movie?api_key=6a98bac66a8fa62e25bcf3b221294b7f&page=1&language=es-ES&sort_by=popularity.desc", requestOptions)
    .then((response) => response.json())
    .then((mydata) => {
      for (const peli of mydata.results) {
        document.getElementById("pelis").innerHTML += `<div class="card" style="width: 200px;">
                <img src="https://image.tmdb.org/t/p/w500/${peli.poster_path}" class="card-img-top" alt="...">
                <div class="card-body">
                    <p>${peli.id}</p>
                    <p class="card-text">${peli.title}</p>
                </div>
            </div>`;
      }
    })
    .catch((error) => console.log("error", error));
}

damePelis();
