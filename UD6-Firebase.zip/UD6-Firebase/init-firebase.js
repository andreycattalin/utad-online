const firebaseConfig = {
  apiKey: "AIzaSyCpIRmx5Imif1tY76dJmZqJUvhjo20UDAg",
  authDomain: "utad-crud.firebaseapp.com",
  projectId: "utad-crud",
  storageBucket: "utad-crud.appspot.com",
  messagingSenderId: "820550694801",
  appId: "1:820550694801:web:4a1ac5020213e0fed40c30",
};
firebase.initializeApp(firebaseConfig);

const firedb = firebase.firestore();

function createTask() {
  let newTask = {
    title: document.getElementById("mytaskinput").value,
    completed: false,
  };

  firedb
    .collection("tasks")
    .add(newTask)
    .then((docRef) => {
      console.log("Document written with ID: ", docRef.id);
      document.getElementById("mytaskinput").value = "";
    })
    .catch((error) => {
      console.error("Error adding document: ", error);
    });
}

function printData() {
  firedb
    .collection("tasks")
    .where("completed", "==", false)
    .onSnapshot((querySnapshot) => {
      document.getElementById("alltasks").innerHTML = "";
      querySnapshot.forEach((doc) => {
        let t = doc.data();
        t.id = doc.id;

        document.getElementById("alltasks").innerHTML += `<li class="list-group-item">
        <div class="form-check me-4">
            <input onchange="updateTask('${t.id}')" class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
            <label class="form-check-label" for="flexCheckDefault">
            ${t.title}
            </label>
            <button onclick="deleteTask('${t.id}')" type="button" class="btn btn-danger">Eliminar</button>
        </div>
      </li>`;
      });
    });
}

printData();

function updateTask(id) {
  firedb.collection("tasks").doc(id).update({
    completed: true,
  });
}

function deleteTask(id) {
  firedb.collection("tasks").doc(id).delete();
}
